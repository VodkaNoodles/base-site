package com.example.vkd_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VkdBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VkdBackendApplication.class, args);
	}

}
