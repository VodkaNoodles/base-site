package com.example.vkd_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VkdBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
